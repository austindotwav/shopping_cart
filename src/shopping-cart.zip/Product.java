public class Product {
    String name;
    double price;
    int quantity;

    // Constructors
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
        this.quantity = 0;
    }
}
